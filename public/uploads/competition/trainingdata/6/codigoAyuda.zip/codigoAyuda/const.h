/*
 * Fichero que incluye las cabeceras y las constantes del programa.
 */

#ifndef _CONST_H_
#define _CONST_H_

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>

#define	TCP	IPPROTO_TCP
#define	N	10
#define	MAX	100
#endif //_CONST_H
