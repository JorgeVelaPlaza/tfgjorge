/* Nombre: serverMT.c
 * Descripci�n: plantilla para versi�n centralizado del algoritmo Ricart y Agrawala
 * Autor: <escribir nombre autor> 
 * 	
 */
#include "const.h"
struct vectorRequesting{
	int id;
	double MT;
};
int getmytime(int sc, int id){
	struct timeval tim;
	double t;

	gettimeofday(&tim, NULL);
        t=tim.tv_sec+(tim.tv_usec/1000000.0);
	t = t + rand () % MAX + 1;  // Dispersi�n de la MT entre 1 y MAX 
	printf("Coordinator: assigning MT=%.lf to client=%d\n", t, id);

	/* TODO:  
 	 * Enviar la MT al proceso 
 	 * Escriba aqui su codigo apdo.c) 
	 */ 		
	return(0);
}

int main(int argc, char *argv[])
{
	int port;
	int solicitud=0;
	int i=0;
	int sd, sc;
	int len;
	int cont=0;
	double marca=0.0;
	struct vectorRequesting vector[N];
	struct sockaddr_in server_addr, client_addr;

	srand (time(NULL));
	
	/* argumentos de entrada */
	if (argc != 2){
		printf("Uso: %s <puerto>\n",argv[0]);
		exit(-1);
	}
	port = atoi(argv[1]);

	/* C�digo del coordinador para acceptar la conexi�n del solicitante */
	if ((sd=socket(AF_INET, SOCK_STREAM, TCP))<0){
		printf("Coordinator: socket error \n");
		exit(-1);
	}
	server_addr.sin_family=AF_INET;
	server_addr.sin_addr.s_addr=INADDR_ANY;
	server_addr.sin_port=htons(port);

	bind(sd, (struct sockaddr*)&server_addr, sizeof(server_addr));
	listen(sd, 5);
	len=sizeof(client_addr);

	printf("Coordinator: waiting connection... \n");
	sc=accept(sd, (struct sockaddr*)&client_addr, (socklen_t *)&len);
	while(cont<N){
		/* TODO:  
 		 * Recibir la solicitud del cliente
 		 * Escriba aqui su codigo apdo.c) 
		 */ 		
		switch(solicitud){
			case 1: /* obtener marca de tiempo */
				getmytime(sc,cont);
				break;
			case 2: /* obtener orden de entrada en la SC */
				
				/* TODO:  
 		 		 * Recibir la MT del cliente
 		  		 * Escriba aqui su codigo apdo.c) 
		 		 */ 		
				
				vector[cont].id=cont;
				vector[cont].MT=marca;
				cont++;
				break;

			default: printf("Coordinator: unknown request \n");
		}
	}
	
	for(i=0;i<N;i++){
		printf("Coordinator: Requesting Process=%d with MT=%.lf\n",vector[i].id, vector[i].MT);
	}

	/* TODO:
 	 * 	El coordinador ordena las Marcas de Tiempo almacenadas en el vector 'vector' 
 	 * 	y enviar� un �nico mensaje para permitir a los N solicitantes entrar en orden en la SC 
 	 *	Escriba aqui su codigo apdo.c) 
	 */ 		

	// ordenarMT(sc, &vector, ...);


	/* TODO:  
 	 * Enviar el orden al proceso 
 	 * Escriba aqui su codigo apdo.c) 
	 */ 		
	
	// enviar
	
	/* cerrar conexion con el cliente */
	close(sc);

	/* Cerrar socket de coordinador */
	close(sd);
	exit(0);
}
