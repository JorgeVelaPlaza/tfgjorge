/* Nombre: solicitante.c
 * Descripci�n: plantilla para versi�n centralizado del algoritmo Ricart y Agrawala
 * Autor: 
 *         
 */

#include "const.h"

int main(int argc, char *argv[]){

	int port = 0;
	char *server = NULL;
	int sd;
	int solicitud;
	struct sockaddr_in serveraddr;
	struct hostent *hp;
	double t;	
	int cont = 0;

	if (argc != 3){
		printf("Uso: %s <direccion_coordinador> <puerto>\n",argv[0]);
		exit(-1);
	}
	
	
	server = argv[1];
	port = atoi(argv[2]);

	printf("server: %s port: %d\n", server, port);

	/* realizar la conexi�n con el servidor */
	if((sd = socket(AF_INET, SOCK_STREAM, TCP))==-1){
		printf("server: %s port: %d\n", server, port);
		exit(-1);
	}

	hp=gethostbyname(server);
	serveraddr.sin_family=AF_INET;
	serveraddr.sin_port=htons(port);
 	memcpy(&serveraddr.sin_addr, hp->h_addr_list[0], hp->h_length);

	if (connect(sd, (struct sockaddr *)&serveraddr, sizeof(struct sockaddr_in))<0){
		printf("cannot connect with server: %s port: %d\n", server, port);
		exit(-1);
	}

	cont = 0;
	while(cont<N){
		solicitud=1;
		/* TODO:
 	 	 * Intercambio de mensajes para solicitar marca de tiempo 
                 * Escriba aqui su codigo apdo.c) 
 	         */                           
			// Ejemplo: send(sd, (char*)&solicitud, sizeof(int),0);
			// 	    recv(sd, &t, sizeof(double),0);
			//	    printf("Requesting process: %d receives %.lf from server %s\n", cont, t, server);
		
		
		solicitud = 2;
		/* TODO:
 	 	 * Intercambio de mensajes para solicitar entrar en la secci�n critica y recibir el orden 
                 * Escriba aqui su codigo apdo.c) 
 	         */                           

		cont++;	
	}
	cont=0;

	/* TODO:
 	 * Intercambio de mensajes para entrar ordenadamente en la secci�n critica 
         * Escriba aqui su codigo apdo.c)  
 	 */                           

	/* cerrar la conexi�n */
	close(sd);
	exit(0);
}
